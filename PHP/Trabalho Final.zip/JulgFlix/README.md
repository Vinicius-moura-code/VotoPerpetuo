# Jugflix

<p> O projeto foi desenvolvido com o objetivo de aplicar os conceitos básicos de
<strong> programação web </strong> dentro da disciplina de Linguagem e programação II.
  
Tornar-se-á público, para ajudar outras pessoas que também iniciam na área, para poderem ter como base desenvolver as suas próprias aplicações e / ou melhorar e integrar a aplicação com outras tecnologias </p>

---

#### In this application, it was used:

- [x] PHP
- [x] HTML
- [x] Css
- [x] Bootstrap
- [x] Javascript

---

### To do:

- [ ] Corrigir Bug's
- [ ] Implementações
  - [ ] Alterar
  - [ ] Deletar
  - [ ] Página de busca geral
  - [ ] Regra de negócio = USUARIO X FORMULARIO
- [ ] New style

---

> Feel at home, show your creativity 🐱‍💻👩‍💻👨‍💻

![Jugflix](https://github.com/Vinicius-moura-code/VotoPerpetuo/blob/main/PHP/JulgFlix/assets/jugflix.png?raw=true "Jugflix")
